package com.capgemini.userstore.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserstoreApplication.class, args);
	}
}
