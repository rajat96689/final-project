package com.capgemini.adminstore.exceptions;

public class MerchantNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MerchantNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MerchantNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MerchantNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MerchantNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MerchantNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
